using io.purplik.ProjectSoul.InventorySystem;

namespace io.purplik.ProjectSoul.EventSystem
{
    public class ItemListener : BaseGameEventListener<Item, ItemGameEvent, UnityItemEvent> { }
}