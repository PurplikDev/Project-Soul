namespace io.purplik.ProjectSoul.EventSystem
{
    public class VoidListener : BaseGameEventListener<Void, VoidGameEvent, UnityVoidEvent> { }
}