using UnityEngine.Events;

namespace io.purplik.ProjectSoul.EventSystem
{
    [System.Serializable] public class UnityVoidEvent : UnityEvent<Void> { }
}