namespace io.purplik.ProjectSoul.EventSystem
{
    [System.Serializable] public struct Void { }
}