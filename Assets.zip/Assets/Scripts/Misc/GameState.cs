public enum GameState
{
    PLAYED,
    PAUSED
}
