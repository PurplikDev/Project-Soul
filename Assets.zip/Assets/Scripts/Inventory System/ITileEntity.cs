using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace io.purplik.ProjectSoul.InventorySystem
{
    public interface ITileEntity
    {
        public void Interact();
    }
}